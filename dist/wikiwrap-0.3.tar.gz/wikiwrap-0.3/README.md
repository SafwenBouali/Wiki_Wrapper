# Wiki Wrapper
Few more functions that can wrap and handle the "Wikipedia" package in python, made into one package.
